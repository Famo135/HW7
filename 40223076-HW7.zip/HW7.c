//Fatemeh Moghiseh   40223076

#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main() {

    int n;
    printf("please enter number of words: ");
    scanf("%d" , &n );

    char lang1[n+1][20], lang2[n+1][20];

    getchar(); 
    for(int i=0 ; i<n ; i++){
        printf("two word%d: " , i+1);
        scanf("%s %s" , &lang1[i] , &lang2[i]);
    }
    
     
    getchar(); 
    char phrase[600];
    char phrase2[600]={};
    printf("Please enter the phrase:\n");
    fgets(phrase,600,stdin);
   

    
    int g=0 , a=0;
    while(g < strlen(phrase)){
        for(int t=0 ; t<n ; t++){
            for(int j=0  ; j<strlen(lang1[t]) ; j++){
                if(tolower(phrase[g+j]) != tolower(lang1[t][j]))
                    break;
                
                else if(j==(strlen(lang1[t])-1)) {
                    if ( (strlen(lang1[t])) > (strlen(lang2[t])) ){

                        for(int k=0 ; k < (strlen(lang2[t])) ; k++){
                            phrase2[a+k]=lang2[t][k];  
                        }
                        a+=strlen(lang2[t]);
                    }
                    else{

                        for(int k=0 ; k<(strlen(lang1[t])) ; k++) {
                            phrase2[a+k]=lang1[t][k];
                         
                        }  
                        a+=strlen(lang1[t]);  
                    }

                    phrase2[a]=' ';
                    a++;
                }
            }
        }
        g++; 
    }
    phrase2[a+1]='\0';

    printf("final phrase:\n%s" , phrase2);
    
    return 0;
}
